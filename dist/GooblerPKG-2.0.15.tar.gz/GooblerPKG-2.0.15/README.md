# Goobler API Wrapper for Python
The all new Goobler API wrapper which you may host your bot on! 

> ⚠️ This package is still in development, so please be patient!

# Basics:

## Sending a simple message
```py
    @GooblerPKG.basic.command()
    def ...(ctx):
        GooblerPKG.basic.msg.Execute.send(ctx, "Hello world!")
```

# Maths:

Nothing is to show here...

# Hosting:

Nothing is to show here...

# How to install this package?

Put this in your Shell tab or Terminal. This will install the package onto your project!
```
git clone https://github.com/WWEMGamer2/GooblerAPIWrapper.git
+-+
pip install gooblerpkg
+-+
pip3 install gooblerpkg
```
To import our package, use:
```py
import GooblerPKG
```

> :warning: This is the official docs and package. If anyone doesn't have something in context, then that package is fake!! Staff members will never ask for your password or personal information. We will only do it at some security times which make sense.
> :dango: Official API help and docs is here: https://goobl2.ericplayzyt.repl.co/docs/api
