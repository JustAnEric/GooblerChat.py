###################
### Goobler 2022 ##
###################
# Scripts made by Eric #

print("[Process] INITIALIZED")