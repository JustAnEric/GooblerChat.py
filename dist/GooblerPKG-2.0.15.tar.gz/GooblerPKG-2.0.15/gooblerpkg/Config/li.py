###################
### Goobler 2022 ##
###################
# Scripts made by Eric #

listarray = [
    {
        "colors_enabled": True, 
        "math_enabled": False, 
    }
]