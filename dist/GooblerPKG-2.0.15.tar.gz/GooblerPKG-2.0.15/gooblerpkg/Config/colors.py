###################
### Goobler 2022 ##
###################
# Scripts made by Eric #

_HEADER = '\033[95m'
_OKBLUE = '\033[94m'
_OKCYAN = '\033[96m'
_OKGREEN = '\033[92m'
_WARNING = '\033[93m'
_FAIL = '\033[91m'
_ENDC = '\033[0m'
_BOLD = '\033[1m'
_UNDERLINE = '\033[4m'

def HEADER():
    return _HEADER
def OKBLUE():
    return _OKBLUE
def OKCYAN():
    return _OKCYAN
def OKGREEN():
    return _OKGREEN
def WARNING():
    return _WARNING
def FAIL():
    return _FAIL
def ENDC():
    return _ENDC
def BOLD():
    return _BOLD
def UNDERLINE():
    return _UNDERLINE