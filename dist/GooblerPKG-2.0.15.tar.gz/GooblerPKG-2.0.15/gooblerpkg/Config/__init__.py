###################
### Goobler 2022 ##
###################
# Scripts made by Eric #

from gooblerpkg.Core import Init

Init()