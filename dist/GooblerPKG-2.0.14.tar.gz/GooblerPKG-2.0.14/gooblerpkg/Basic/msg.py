###################
### Goobler 2022 ##
###################
# Scripts made by Eric #


class Execute:
  def send(ctx, message):
    return 0