###################
### Goobler 2022 ##
###################
# Scripts made by Eric #